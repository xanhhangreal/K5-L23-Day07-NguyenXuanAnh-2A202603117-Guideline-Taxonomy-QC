# Báo cáo QC tự động

**HOLD**

## Vòng 1 — full
- Ảnh đã duyệt 1/40; cả lô 40 ảnh.
- Ảnh có lỗi trên ảnh đã duyệt: 1/1 = 100.0%.
- Annotation đối tượng hiện có bị lỗi: 1/8 = 12.5%.
- Vật bỏ sót ghi riêng: 0.
- IAA trước calibration dùng để chẩn đoán; đối chiếu iaa_summary.md.
- ca_kho: đã duyệt 1/39, ảnh có lỗi 1/1 = 100.0%.
- con_lai: đã duyệt 0/1, ảnh có lỗi 0/0 (N/A).
- sai_vi_tri_kich_thuoc: 1 lỗi.
- Tỉ lệ ảnh có lỗi vượt ngưỡng lớp học 2%.
- Chưa duyệt: img_002.jpg, img_003.jpg, img_004.jpg, img_005.jpg, img_006.jpg, img_007.jpg, img_008.jpg, img_009.jpg, img_010.jpg, img_011.jpg, img_012.jpg, img_013.jpg, img_014.jpg, img_015.jpg, img_016.jpg, img_017.jpg, img_018.jpg, img_019.jpg, img_020.jpg, img_021.jpg, img_022.jpg, img_023.jpg, img_024.jpg, img_025.jpg, img_026.jpg, img_027.jpg, img_028.jpg, img_029.jpg, img_030.jpg, img_031.jpg, img_032.jpg, img_033.jpg, img_034.jpg, img_035.jpg, img_036.jpg, img_037.jpg, img_038.jpg, img_039.jpg, img_040.jpg
- Guideline còn 1 ca chưa chốt, 0 ảnh có vấn đề.
- Nhãn cuối còn box đánh dấu can_review.
